package com.kontrolmerkezi.app

import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

class MediaListener : NotificationListenerService() {
    override fun onListenerConnected() { instance = this; refreshControllers() }
    override fun onListenerDisconnected() { instance = null; controllers = emptyList() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { refreshControllers() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refreshControllers() }
    private fun refreshControllers() {
        try {
            controllers = getActiveSessions(null).filter { it.packageName == "com.spotify.music" || it.playbackState != null }
            controllers.forEach { c -> c.registerCallback(object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) { pushUpdate() }
                override fun onPlaybackStateChanged(state: PlaybackState?) { pushUpdate() }
            }) }
            pushUpdate()
        } catch (_: Exception) { }
    }
    companion object {
        @Volatile private var instance: MediaListener? = null
        @Volatile private var controllers: List<MediaController> = emptyList()
        private fun active(): MediaController? = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: controllers.firstOrNull()
        fun command(which: String) {
            val c = active() ?: return
            when (which) {
                "toggle" -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
                "next" -> c.transportControls.skipToNext()
                "previous" -> c.transportControls.skipToPrevious()
            }
        }
        fun currentJson(): String {
            val c = active(); val m = c?.metadata; val s = c?.playbackState
            val j = JSONObject()
            j.put("title", m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Şu an çalan yok")
            j.put("artist", m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "Spotify veya müzik uygulamasını aç")
            j.put("playing", s?.state == PlaybackState.STATE_PLAYING)
            j.put("position", s?.position ?: 0)
            j.put("duration", m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0)
            val art = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            if (art != null) {
                try {
                    val out = java.io.ByteArrayOutputStream(); art.compress(android.graphics.Bitmap.CompressFormat.JPEG, 75, out)
                    j.put("art", "data:image/jpeg;base64," + android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP))
                } catch (_: Exception) { }
            }
            return j.toString()
        }
        private fun pushUpdate() { /* WebView refreshes on resume and via its refresh button. */ }
    }
}
