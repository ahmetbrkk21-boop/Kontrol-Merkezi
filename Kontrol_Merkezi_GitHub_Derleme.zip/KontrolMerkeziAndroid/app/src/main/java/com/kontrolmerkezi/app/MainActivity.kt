package com.kontrolmerkezi.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "AndroidMedia")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        if (!Settings.Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty().contains(packageName)) {
            Toast.makeText(this, "Spotify bağlantısı için medya/bildirim erişimini açın.", Toast.LENGTH_LONG).show()
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
    }
    inner class Bridge {
        @JavascriptInterface fun playPause() = MediaListener.command("toggle")
        @JavascriptInterface fun next() = MediaListener.command("next")
        @JavascriptInterface fun previous() = MediaListener.command("previous")
        @JavascriptInterface fun refresh() { runOnUiThread { web.evaluateJavascript("window.updateNativeMedia && window.updateNativeMedia(${MediaListener.currentJson()})", null) } }
    }
    override fun onResume() {
        super.onResume()
        web.postDelayed({ web.evaluateJavascript("window.updateNativeMedia && window.updateNativeMedia(${MediaListener.currentJson()})", null) }, 700)
    }
}
