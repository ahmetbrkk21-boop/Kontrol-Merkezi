TELEFONDAN APK DERLEME
1) Bu klasordeki dosyalari GitHub'da yeni bir depoya (repository) yukle; klasor yapisini aynen koru.
2) GitHub deposunda Actions sekmesine gir.
3) 'Build Kontrol Merkezi APK' is akisina girip Run workflow'ya bas.
4) Islem tamamlaninca calismanin altindaki Artifacts bolumunden Kontrol-Merkezi-APK dosyasini indir.
5) ZIP'i ac; app-debug.apk dosyasini telefona kur.

Bu kaynak proje/derleme tarifi test edilmis bir APK garantisi degildir. Derleme hatasi cikarsa hata metnini paylas.
