KONTROL MERKEZI - ANDROID KAYNAK PROJESI

Bu paket APK degildir; Android Studio ile derlenebilir kaynak projedir.
Icerik: mevcut Kontrol Merkezi HTML arayuzu + Android WebView kabugu + Android MediaSession/NotificationListener entegrasyonu.

APK olusturmak icin Android Studio ve Android SDK gerekir:
1. Projeyi Android Studio'da acin.
2. Gradle senkronizasyonunu tamamlayin.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Telefona kurun.
5. Ilk acilista Bildirim/medya erisimi ekraninda Kontrol Merkezi'ne izin verin.
6. Spotify'da muzik baslatin; panelde sarki bilgisi ve kontrol tuslari gorunur.

Not: Bu kaynak proje derlenmeden telefona yuklenemez. Spotify uygulamasinin Android MediaSession yayini ve cihaz/Android surumu davranisi uyumlulugu etkileyebilir.
